for i in 0..5
   if i < 2 then
      next
   else
   end
   puts "Value of local variable is #{i}"
end

