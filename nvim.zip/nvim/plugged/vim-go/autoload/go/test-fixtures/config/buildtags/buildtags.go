package config

func Example() {
	foo()
}
